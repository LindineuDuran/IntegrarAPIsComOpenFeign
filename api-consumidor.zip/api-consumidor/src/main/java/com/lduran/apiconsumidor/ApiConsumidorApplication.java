package com.lduran.apiconsumidor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiConsumidorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiConsumidorApplication.class, args);
	}

}
