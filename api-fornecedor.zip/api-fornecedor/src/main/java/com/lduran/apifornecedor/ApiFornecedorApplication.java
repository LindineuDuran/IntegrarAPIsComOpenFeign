package com.lduran.apifornecedor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiFornecedorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiFornecedorApplication.class, args);
	}

}
